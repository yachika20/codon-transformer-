"""Model weights, tokenizer, and other resources."""
